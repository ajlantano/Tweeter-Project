<?php $__env->startSection('content'); ?>
<?php if(Auth::id() == $user->id ): ?>
<div class="">
    <a class = "btn btn-dark" href="/profiles/<?php echo e($user->id); ?>/edit">Edit Profile</a>

</div>
<?php endif; ?>
<h1><?php echo e($user->name); ?></h1>
<ul class="list-group list-group-flush">
  <li class="list-group-item"><?php echo e($user->profile->bio); ?></li>
  <li class="list-group-item"><?php echo e($user->profile->location); ?></li>
  <li class="list-group-item"><?php echo e($user->profile->birthday); ?></li>
  <li class="list-group-item"><?php echo e($user->profile->website); ?></li>
</ul>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>