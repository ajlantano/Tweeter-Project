<div>
        <hr />
    <h6>Comment</h6>
    <form method="post" action="<?php echo e(route('comment.add' ,  ['id' => $tweet->id])); ?>">
        <?php echo csrf_field(); ?>
    <div class="form-group">
        <input type="text" name="comment_body" class="form-control" />
        <div class="form-group">
            <input type="submit" class="btn btn-dark" value="Add Comment" />
        </div>
    </div>
</div>
