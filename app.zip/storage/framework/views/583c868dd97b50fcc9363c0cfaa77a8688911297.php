<?php $__env->startSection('content'); ?>
<h1 class="title">Create Tweet</h1>
<form class="form-group" action="/tweets" method="POST">
    <?php echo $__env->make('tweets._form', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>