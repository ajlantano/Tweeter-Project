<?php $__env->startSection('content'); ?>
<h1 class="title">Edit Tweet</h1>
<form action="/tweets/<?php echo e($tweet->id); ?>" method="POST">
    <input type="hidden" name="_method" value="PUT">
    <?php echo $__env->make('tweets._form', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</form>
<form action="/tweets/<?php echo e($tweet->id); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <?php echo e(method_field('DELETE')); ?>

    <button type="submit" class="btn btn-danger">Delete</button>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>