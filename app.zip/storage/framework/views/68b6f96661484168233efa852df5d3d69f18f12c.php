<?php echo csrf_field(); ?>
<div class="form-group">
    <textarea class="form-control" name="body" rows="8" cols="80" placeholder="Put Your Tweety Tweet Here"><?php echo e(old('body',$tweet->body)); ?></textarea>
</div>
<div class="form-group">
    <?php if($errors->any()): ?>
    <ul class="alert alert-secondary">
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($error); ?></li>
    </ul>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
    <?php endif; ?>
<div class="form-group">
        <button type="submit" class="btn btn-dark">Submit</button>

</div>
