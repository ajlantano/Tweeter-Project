<div class="card">
    <div class="card-body">
        <h5 class="card-tite"><?php echo e($tweet->user->name); ?></h5>
        <div class="card-text">
            <?php echo e($tweet->body); ?>

        </div>
    </div>
</div>
