<div class="card">
    <div class="card-body">
        <h5 class="card-tite"><?php echo e($tweet->user->name); ?> </h5>
        <div class="card-text">
            <?php echo e($tweet->body); ?>

        </div>
        <div class="card-body">
            <a href="/tweets/<?php echo e($tweet->id); ?>">Comment</a>
            <a href="/likes/<?php echo e($tweet->id); ?>/tweet"><?php echo e(($tweet->is_liked ? 'Unlike' : 'Like' )); ?></a>
            <a href="/tweets/<?php echo e($tweet->id); ?>/edit">Edit</a>
        </div>
    </div>
</div>
