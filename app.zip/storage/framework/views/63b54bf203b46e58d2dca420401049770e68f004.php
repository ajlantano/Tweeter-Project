<?php $__env->startSection('content'); ?>
<form class="" action="/profiles/<?php echo e($user->id); ?>" method="post">
    <?php echo csrf_field(); ?>
    <?php echo e(method_field('put')); ?>

    <div class="">
        <label>Location</label>
        <input type="text" name="location" value="<?php echo e($user->profile->location); ?>">
    </div>
    <div class="">
        <label>Birthday</label>
        <input type="date" name="birthday" value="<?php echo e($user->profile->birthday); ?>">
    </div>
    <div class="">
        <label>Website</label>
        <input type="text" name="website" value="<?php echo e($user->profile->website); ?>">
    </div>
    <div class="">
        <label>Bio</label>
        <textarea class="form-control" name="bio" rows="8" cols="80"><?php echo e($user->profile->bio); ?></textarea>
    </div>
    <div class="">
        <button type="submit" class="btn btn-dark">Save</button>
    </div>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>