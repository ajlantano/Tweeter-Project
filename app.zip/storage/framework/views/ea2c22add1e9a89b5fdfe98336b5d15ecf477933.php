<div class="card">
    <div class="card-body">
        <h5 class="card-tite"><?php echo e($comment->user->name); ?></h5>
        <div class="card-text">
            <?php echo e($comment->body); ?>

        </div>
        <div class="card-text">
            <a href="/tweets/<?php echo e($tweet->id); ?>/comments/<?php echo e($comment->id); ?>/edit">Edit</a>
            <a href="/likes/<?php echo e($comment->id); ?>/comments"><?php echo e(($comment->is_liked ? 'Unlike' : 'Like' )); ?></a>
        </div>
    </div>
</div>
